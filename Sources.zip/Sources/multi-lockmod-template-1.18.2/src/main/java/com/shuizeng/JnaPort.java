package com.shuizeng;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.WinNT;

public interface JnaPort extends Library {
    JnaPort INSTANCE = Native.load("ntdll", JnaPort.class);

    int NtSuspendProcess(WinNT.HANDLE ProcessHandle);
    @SuppressWarnings("unused")
    int NtResumeProcess(WinNT.HANDLE ProcessHandle);

}
