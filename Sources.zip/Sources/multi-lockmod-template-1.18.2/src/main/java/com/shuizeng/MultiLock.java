package com.shuizeng;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultiLock implements ModInitializer {
    public static final String MOD_ID = "multi-lockmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("MultiLock loaded");
        GetPID.writePidFile();
    }
}