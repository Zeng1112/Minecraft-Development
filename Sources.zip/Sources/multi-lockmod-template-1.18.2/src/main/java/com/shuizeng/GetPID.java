package com.shuizeng;

import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ProcessHandle;
import java.nio.file.Path;

public class GetPID {
    private static final Logger LOGGER = LoggerFactory.getLogger("GetPID");

    public static void writePidFile() {
        Path instanceDir = FabricLoader.getInstance().getGameDir();
        LOGGER.info("GetPID：实例目录 = {}", instanceDir);

        long pid;
        try {
            pid = ProcessHandle.current().pid();
            LOGGER.info("当前进程PID = {}", pid);
        } catch (Throwable t) {
            LOGGER.error("获取PID失败", t);
            return;
        }

        Path out = instanceDir.resolve("modstateout.txt");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(out.toFile()))) {
            bw.write("pid=" + pid);
            bw.newLine();
            LOGGER.info("✅ modstateout.txt 写入成功");
        } catch (IOException e) {
            LOGGER.error("❌ 写入文件失败", e);
        }
    }
}