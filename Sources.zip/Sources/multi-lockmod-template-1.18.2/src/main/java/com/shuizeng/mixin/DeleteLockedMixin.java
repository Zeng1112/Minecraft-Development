package com.shuizeng.mixin;

import com.shuizeng.DeleteLocked;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(targets = "me.voidxwalker.autoreset.Atum", remap = false)
public class DeleteLockedMixin {
    @Inject(method = "createNewWorld", at = @At("HEAD"), remap = false)
    private static void hookAtumCreateNewWorld(CallbackInfo ci) {
        DeleteLocked.startWatch();
    }
}