package com.shuizeng.mixin;

import com.shuizeng.DeleteLocked;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(targets = "me.voidxwalker.autoreset.Atum", remap = false)
public class RefuseResetMixin {

    @Inject(method = "scheduleReset", at = @At("HEAD"), remap = false, cancellable = true)
    private static void scheduleReset(CallbackInfo ci) {
        if (DeleteLocked.isLockedDetected()) {
            System.out.println("[MultiLock] 检测到锁标记，拦截重开");
            ci.cancel();
        } else {
            System.out.println("[MultiLock] 无锁，放行重开");
        }
    }
}