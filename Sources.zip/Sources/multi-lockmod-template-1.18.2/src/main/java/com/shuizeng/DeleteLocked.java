package com.shuizeng;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DeleteLocked {
    private static final Logger LOGGER = LoggerFactory.getLogger("multilock");
    private static volatile boolean watching = false;
    private static volatile boolean lockedDetected = false;
    private static Thread watchThread;

    public static void startWatch() {
        String gameDirProp = System.getProperty("user.dir");
        if (gameDirProp == null || gameDirProp.isBlank()) {
            LOGGER.error("[MultiLock] user.dir 为空");
            return;
        }
        Path mcDir = Paths.get(gameDirProp);
        Path locked = mcDir.resolve("locked");

        LOGGER.info("[MultiLock] 删除locked = {}", locked);
        try {
            boolean removed = Files.deleteIfExists(locked);
            LOGGER.info("[MultiLock] 删除结果: {}", removed);

            stopWatch();
            watching = true;
            final Path currentLocked = locked;
            watchThread = new Thread(() -> {
                while (watching) {
                    boolean exist = Files.exists(currentLocked);
                    lockedDetected = exist;
                    LOGGER.info("[MultiLock] locked文件存在: {}", exist);
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        LOGGER.info("[MultiLock] 监听线程退出");
                        break;
                    }
                }
                lockedDetected = false;
            }, "LockWatchThread");
            watchThread.setDaemon(true);
            watchThread.start();
        } catch (Exception e) {
            LOGGER.error("[MultiLock] 删除locked发生IO异常", e);
        }
    }

    public static void stopWatch() {
        watching = false;
        if (watchThread != null) {
            watchThread.interrupt();
            watchThread = null;
        }
        lockedDetected = false;
    }

    public static boolean isLockedDetected() {
        return lockedDetected;
    }
}